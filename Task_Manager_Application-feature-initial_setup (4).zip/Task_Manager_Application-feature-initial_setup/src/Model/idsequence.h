#ifndef IDSEQUENCE_H
#define IDSEQUENCE_H

#include <QDialog>

class IdSequence
{
public:
    IdSequence();
    long int createTaskId();
};

#endif // IDSEQUENCE_H
